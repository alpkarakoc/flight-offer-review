package com.flight.server;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@RestController
@RequestMapping("/api/selections")
public class SelectionController {

    // R4 kuralı gereği: Müsaitlik/sürüm değişimlerini bellekte tutuyoruz
    private final Map<String, Integer> currentOfferVersions = new ConcurrentHashMap<>();

    public SelectionController() {
        // İstemci v1 gönderecek, ancak sunucu belleğinde teklif v2'ye geçmiş olacak.
        currentOfferVersions.put("OFFER-1", 2);
    }

    @PostMapping
    public ResponseEntity<?> validateSelection(@RequestBody SelectionRequest request) {
        if (request.offerId() == null || request.version() <= 0) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(new ErrorResponse("INVALID_REQUEST", "Invalid request parameters."));
        }

        Integer currentVersion = currentOfferVersions.get(request.offerId());

        if (currentVersion == null) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND)
                    .body(new ErrorResponse("OFFER_NOT_FOUND", "The offer is unknown."));
        }

        if (currentVersion > request.version()) {
            return ResponseEntity.status(HttpStatus.CONFLICT)
                    .body(new ErrorResponse("OFFER_STALE", "The offer has changed. Search again."));
        }

        return ResponseEntity.ok(Map.of(
                "status", "VALIDATED",
                "offerId", request.offerId(),
                "version", request.version()
        ));
    }
}
