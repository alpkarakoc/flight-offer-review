package com.flight.server;

public record SelectionRequest(String offerId, int version) {}
