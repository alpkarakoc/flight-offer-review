package com.flight.server;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.hamcrest.Matchers.is;

@SpringBootTest
@AutoConfigureMockMvc
public class SelectionApiTest {

    @Autowired
    private MockMvc mockMvc;

    @Test
    public void rejectsStaleOfferVersionWith409() throws Exception {
        // Hedef: Sunucu belleğinde OFFER-1 v2 olarak kayıtlıyken,
        // istemci v1 talep ettiğinde sunucu 409 OFFER_STALE dönmelidir.
        
        String requestJson = """
            {
              "offerId": "OFFER-1",
              "version": 1
            }
            """;

        mockMvc.perform(post("/api/selections")
                .contentType(MediaType.APPLICATION_JSON)
                .content(requestJson))
            .andExpect(status().isConflict())
            .andExpect(jsonPath("$.code", is("OFFER_STALE")));
    }
}
